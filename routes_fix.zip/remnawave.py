# services/remnawave.py - Интеграция с Remnawave API
#
# ====== ВАЖНО ======
# Remnawave имеет ProxyCheckGuard — он требует заголовки:
#   X-Forwarded-Proto: https
#   X-Forwarded-For: 127.0.0.1
# Без них запросы отклоняются (socket destroyed → 404/connection error).
# Мы добавляем эти заголовки всегда.
#
# Правильные маршруты (из backend-contract):
#   POST   /api/users                          - создать пользователя
#   GET    /api/users/:uuid                    - получить пользователя
#   PATCH  /api/users/:uuid                    - обновить пользователя
#   DELETE /api/users/:uuid                    - удалить пользователя
#   POST   /api/users/actions/enable/:uuid     - активировать
#   POST   /api/users/actions/disable/:uuid    - деактивировать

import logging
import httpx
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class RemnawaveAPI:
    """
    Клиент для работы с Remnawave API.

    Токен: Settings → API Tokens → Create Token (в панели)
    Заголовок: Authorization: Bearer <token>

    Обязательные заголовки для обхода ProxyCheckGuard:
      X-Forwarded-Proto: https
      X-Forwarded-For: 127.0.0.1
    """

    def __init__(self, base_url: str, api_token: str):
        self.base_url = base_url.rstrip("/")
        self.token = api_token

        # КРИТИЧНО: добавляем proxy-заголовки, иначе ProxyCheckGuard
        # уничтожит соединение и вернёт 404 или connection error.
        self.headers = {
            "Authorization": f"Bearer {api_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            # Обход ProxyCheckGuard (обязателен даже для HTTP-соединений)
            "X-Forwarded-Proto": "https",
            "X-Forwarded-For": "127.0.0.1",
        }

    def _request(self, method: str, path: str, **kwargs) -> dict | None:
        """Выполнить HTTP запрос к Remnawave API."""
        url = f"{self.base_url}{path}"
        try:
            with httpx.Client(timeout=15, headers=self.headers) as client:
                resp = client.request(method, url, **kwargs)

                logger.debug(f"→ {method} {url}  body={kwargs.get('json')}")
                logger.debug(f"← {resp.status_code}: {resp.text[:500]}")

                # Диагностические сообщения для частых ошибок
                if resp.status_code == 404:
                    logger.error(
                        f"[Remnawave 404] {method} {url}\n"
                        f"  Проверьте REMNAWAVE_API_URL — текущее значение: {self.base_url}\n"
                        f"  Должно быть без /api на конце: http://remnawave:3000 или https://panel.example.com\n"
                        f"  Если бот в том же Docker Compose — используйте имя сервиса: http://remnawave:3000"
                    )
                    return None

                if resp.status_code == 401:
                    logger.error(
                        "[Remnawave 401] Неверный API токен.\n"
                        "  Создайте токен: панель → Settings → API Tokens → Create Token"
                    )
                    return None

                if resp.status_code == 403:
                    logger.error("[Remnawave 403] Токен не имеет прав на это действие.")
                    return None

                if resp.status_code == 422:
                    logger.error(
                        f"[Remnawave 422] Ошибка валидации тела запроса.\n"
                        f"  Тело: {kwargs.get('json')}\n"
                        f"  Ответ: {resp.text}"
                    )
                    return None

                resp.raise_for_status()

                if not resp.content:
                    return {}

                data = resp.json()
                # Remnawave оборачивает успешные ответы в {"response": {...}}
                if isinstance(data, dict) and "response" in data:
                    return data["response"]
                return data

        except httpx.ConnectError as e:
            logger.error(
                f"[Remnawave] Нет соединения: {e}\n"
                f"  URL: {url}\n"
                f"  Проверьте сетевую доступность панели и правильность REMNAWAVE_API_URL"
            )
            return None
        except httpx.ReadError as e:
            logger.error(
                f"[Remnawave] Соединение сброшено сервером: {e}\n"
                f"  URL: {url}\n"
                f"  Возможная причина: ProxyCheckGuard отклонил запрос.\n"
                f"  Убедитесь что заголовки X-Forwarded-Proto и X-Forwarded-For присутствуют."
            )
            return None
        except httpx.HTTPStatusError as e:
            logger.error(
                f"[Remnawave] HTTP {e.response.status_code} на {url}\n"
                f"  Ответ: {e.response.text[:500]}"
            )
            return None
        except Exception as e:
            logger.error(f"[Remnawave] Неожиданная ошибка [{method} {url}]: {e}")
            return None

    # ==================== USERS ====================

    def create_user(
        self,
        telegram_id: int,
        username: str,
        days: int,
        traffic_bytes: int = 0,
    ) -> dict | None:
        """
        POST /api/users
        
        Обязательные поля:
          username            — только a-z, 0-9, _ (без пробелов и @)
          trafficLimitBytes   — 0 = безлимит
          trafficLimitStrategy— "NO_RESET"
          expireAt            — ISO 8601 UTC: "2025-01-01T12:00:00.000Z"
          telegramId          — число (int), не строка!
          activeUserInbounds  — [] = все активные инбаунды
        """
        expire_at = (datetime.utcnow() + timedelta(days=days)).strftime(
            "%Y-%m-%dT%H:%M:%S.000Z"
        )
        # username должен быть строго a-z0-9_ — только ASCII, никакого @
        safe_username = f"tg_{telegram_id}"

        payload = {
            "username": safe_username,
            "trafficLimitBytes": traffic_bytes,
            "trafficLimitStrategy": "NO_RESET",
            "expireAt": expire_at,
            "telegramId": telegram_id,  # int, не str!
            "description": f"@{username}" if username else str(telegram_id),
            "activeUserInbounds": [],                 # [] = все инбаунды
        }

        logger.info(f"[Remnawave] Создание пользователя: {safe_username}, expire={expire_at}")
        result = self._request("POST", "/api/users", json=payload)

        if result:
            logger.info(
                f"[Remnawave] ✅ Пользователь создан: uuid={result.get('uuid')}"
            )
        return result

    def get_user(self, uuid: str) -> dict | None:
        """GET /api/users/:uuid"""
        return self._request("GET", f"/api/users/{uuid}")

    def get_user_by_username(self, username: str) -> dict | None:
        """GET /api/users/username/:username"""
        return self._request("GET", f"/api/users/username/{username}")

    def delete_user(self, uuid: str) -> bool:
        """DELETE /api/users/:uuid"""
        result = self._request("DELETE", f"/api/users/{uuid}")
        return result is not None

    def enable_user(self, uuid: str) -> dict | None:
        """POST /api/users/:uuid/actions/enable"""
        return self._request("POST", f"/api/users/{uuid}/actions/enable")

    def disable_user(self, uuid: str) -> dict | None:
        """POST /api/users/:uuid/actions/disable"""
        return self._request("POST", f"/api/users/{uuid}/actions/disable")

    def update_user(self, uuid: str, **fields) -> dict | None:
        """
        PATCH /api/users/:uuid
        
        Поддерживаемые поля: expireAt, trafficLimitBytes,
        description, telegramId, hwidDeviceLimit и др.
        """
        return self._request("PATCH", f"/api/users/{uuid}", json=fields)

    def update_expiry(self, uuid: str, new_expire: datetime) -> dict | None:
        """Обновить дату окончания подписки"""
        expire_str = new_expire.strftime("%Y-%m-%dT%H:%M:%S.000Z")
        return self.update_user(uuid, expireAt=expire_str)

    def set_device_limit(self, uuid: str, limit: int) -> dict | None:
        """Установить лимит HWID-устройств"""
        return self.update_user(uuid, hwidDeviceLimit=limit)

    def get_subscription_link(self, uuid: str) -> str | None:
        """
        Получить ссылку подписки из объекта пользователя.
        Remnawave хранит её в поле subscriptionUrl.
        """
        user = self.get_user(uuid)
        if not user:
            return None

        sub_url = (
            user.get("subscriptionUrl")
            or user.get("subUrl")
            or user.get("subscription_url")
        )

        if not sub_url:
            # Формируем из shortUuid если subscriptionUrl пустой
            short_uuid = user.get("shortUuid") or user.get("short_uuid")
            if short_uuid:
                sub_url = f"{self.base_url}/api/sub/{short_uuid}"

        logger.debug(f"[Remnawave] Ссылка подписки для {uuid}: {sub_url}")
        return sub_url

    def ping(self) -> bool:
        """Проверить доступность API (GET /api/keygen/get-pub-key)"""
        try:
            with httpx.Client(timeout=5, headers=self.headers) as client:
                resp = client.get(f"{self.base_url}/api/keygen/get-pub-key")
                logger.info(f"[Remnawave] ping → {resp.status_code}")
                # 200 = OK, 401 = API работает но токен не тот (тоже ок для ping)
                return resp.status_code < 500
        except httpx.ConnectError:
            logger.error(f"[Remnawave] ping failed — нет соединения с {self.base_url}")
            return False
        except Exception as e:
            logger.error(f"[Remnawave] ping error: {e}")
            return False

    # ==================== SQUADS ====================

    def get_all_squads(self) -> list:
        """GET /api/internal-squads — получить все squads"""
        result = self._request("GET", "/api/internal-squads")
        if result is None:
            return []
        # Ответ может быть списком напрямую или {"squads": [...]}
        if isinstance(result, list):
            return result
        return result.get("squads", result.get("response", []))

    def add_user_to_squad(self, squad_uuid: str, user_uuid: str) -> bool:
        """
        POST /api/internal-squads/:uuid/users/add
        Body: {"userUuids": ["user-uuid"]}
        По аналогии с /api/users/:uuid/actions/... — uuid идёт перед действием.
        """
        # Правильный маршрут по аналогии с users/actions
        result = self._request(
            "POST", f"/api/internal-squads/{squad_uuid}/users/add",
            json={"userUuids": [user_uuid]},
        )
        if result is not None:
            logger.info(f"[Remnawave] ✅ {user_uuid} добавлен в Squad {squad_uuid}")
            return True

        # Fallback: без /add
        result = self._request(
            "POST", f"/api/internal-squads/{squad_uuid}/users",
            json={"userUuids": [user_uuid]},
        )
        if result is not None:
            logger.info(f"[Remnawave] ✅ {user_uuid} добавлен в Squad {squad_uuid}")
            return True

        logger.error(f"[Remnawave] ❌ Не удалось добавить {user_uuid} в Squad {squad_uuid}")
        return False
