# 🛡 VPN Bot — MVP

Два Telegram бота для VPN сервиса на базе Remnawave.

- **Клиентский бот** — триал, покупка подписок (Telegram Stars), управление VPN
- **Админ бот** — управление пользователями, рассылка

---

## 📁 Структура

```
vpn_bot/
├── bot_admin/        # Админ-бот
├── bot_client/       # Клиентский бот
├── database/         # SQLite (db.py)
├── services/         # Remnawave API, бизнес-логика
├── config.py         # Конфиг из .env
├── main.py           # Точка входа
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
└── .env.example
```

---

## 🚀 Быстрый старт

### 1. Клонировать / скопировать проект

```bash
git clone <repo> vpn_bot && cd vpn_bot
```

### 2. Создать `.env`

```bash
cp .env.example .env
nano .env   # заполните токены
```

Минимум нужно заполнить:
- `CLIENT_BOT_TOKEN` — токен клиентского бота
- `ADMIN_BOT_TOKEN` — токен админ-бота  
- `ADMIN_IDS` — ваш Telegram ID
- `REMNAWAVE_API_URL` — URL Remnawave
- `REMNAWAVE_API_TOKEN` — токен Remnawave

### 3а. Запуск через Docker (рекомендуется)

```bash
docker compose up -d --build
docker compose logs -f
```

### 3б. Запуск без Docker

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

---

## 💡 Как получить токен бота

1. Напишите [@BotFather](https://t.me/botfather) в Telegram
2. `/newbot` → введите имя → получите токен
3. Повторите для второго бота (админ)

## 💡 Как узнать свой Telegram ID

Напишите [@userinfobot](https://t.me/userinfobot) — он пришлёт ваш ID.

---

## 💳 Оплата Telegram Stars

Telegram Stars (`XTR`) работают без подключения платёжных систем.
Достаточно токена бота — всё встроено в Telegram.

> ⚠️ Для Stars не нужен `PAYMENTS_TOKEN` — просто используйте `currency="XTR"`.

---

## ⚙️ Тарифы

Тарифы захардкожены в `config.py`:

```python
TARIFFS = {
    "14d": {"name": "14 дней", "days": 14, "stars": 100},
    "30d": {"name": "30 дней", "days": 30, "stars": 180},
    "90d": {"name": "90 дней", "days": 90, "stars": 450},
}
```

Измените цены по необходимости.

---

## 🔌 Remnawave API

Проект использует следующие эндпоинты:

| Метод | Путь | Описание |
|-------|------|----------|
| POST | `/api/users` | Создать пользователя |
| DELETE | `/api/users/{uuid}` | Удалить |
| PATCH | `/api/users/{uuid}/enable` | Активировать |
| PATCH | `/api/users/{uuid}/disable` | Деактивировать |
| GET | `/api/users/{uuid}` | Данные + ссылка |
| PATCH | `/api/users/{uuid}` | Обновить (срок, лимит устройств) |

Если ваша версия Remnawave использует другие пути — отредактируйте `services/remnawave.py`.

---

## 🗃 База данных

SQLite файл создаётся автоматически в `data/vpn_bot.db`.

Схема:

```sql
-- Пользователи
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    telegram_id INTEGER UNIQUE,
    username TEXT,
    remnawave_id TEXT,
    is_trial_used INTEGER DEFAULT 0,
    device_limit INTEGER DEFAULT 1,
    subscription_end TEXT,
    is_active INTEGER DEFAULT 1,
    created_at TEXT
);

-- Платежи
CREATE TABLE payments (
    id INTEGER PRIMARY KEY,
    user_id INTEGER,
    telegram_charge_id TEXT,
    amount INTEGER,
    type TEXT,
    status TEXT,
    created_at TEXT
);
```

---

## 🔧 Часто задаваемые вопросы

**Q: Боты не запускаются?**  
A: Проверьте `.env` — все 3 основных токена должны быть заполнены.

**Q: Ошибка при создании пользователя в Remnawave?**  
A: Проверьте `REMNAWAVE_API_URL` и `REMNAWAVE_API_TOKEN`. Посмотрите логи: `docker compose logs -f`.

**Q: Как добавить новый тариф?**  
A: Добавьте в `TARIFFS` в `config.py` — всё остальное подхватится автоматически.
