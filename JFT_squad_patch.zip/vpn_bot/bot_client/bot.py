# bot_client/bot.py - Клиентский Telegram бот
import asyncio
import logging
from datetime import datetime

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import (
    Message, CallbackQuery,
    InlineKeyboardMarkup, InlineKeyboardButton,
    LabeledPrice, PreCheckoutQuery,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import TARIFFS, EXTRA_DEVICE_STARS
from database import db
from services.vpn_service import VPNService

logger = logging.getLogger(__name__)


def build_main_menu() -> InlineKeyboardMarkup:
    """Главное меню клиента"""
    builder = InlineKeyboardBuilder()
    builder.button(text="🧾 Мой аккаунт", callback_data="account")
    builder.button(text="💳 Купить подписку", callback_data="buy")
    builder.button(text="📡 Мой VPN", callback_data="myvpn")
    builder.button(text="ℹ️ О сервисе", callback_data="about")
    builder.adjust(2)
    return builder.as_markup()


def build_tariffs_menu() -> InlineKeyboardMarkup:
    """Меню выбора тарифа"""
    builder = InlineKeyboardBuilder()
    for key, tariff in TARIFFS.items():
        builder.button(
            text=f"{tariff['name']} — {tariff['stars']} ⭐",
            callback_data=f"buy_{key}"
        )
    builder.button(text="➕ Доп. устройство", callback_data="buy_device")
    builder.button(text="◀️ Назад", callback_data="menu")
    builder.adjust(1)
    return builder.as_markup()


def setup_client_bot(token: str, vpn_service: VPNService, db_path: str):
    """Настройка и возврат диспетчера клиентского бота"""
    bot = Bot(token=token)
    dp = Dispatcher()

    # ========== /start ==========
    @dp.message(CommandStart())
    async def cmd_start(message: Message):
        user = vpn_service.get_or_create_user(
            message.from_user.id,
            message.from_user.username
        )

        # Новый пользователь — предлагаем триал
        if not user["is_trial_used"]:
            await message.answer(
                "👋 Добро пожаловать в VPN сервис!\n\n"
                "🎁 Для вас доступен бесплатный триал:\n"
                f"• 3 дня\n• До 5 ГБ в день\n• 1 устройство\n\n"
                "Хотите активировать?",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text="✅ Активировать триал", callback_data="trial"),
                    InlineKeyboardButton(text="💳 Купить сразу", callback_data="buy"),
                ]])
            )
        else:
            await message.answer(
                "👋 Добро пожаловать!\nВыберите действие:",
                reply_markup=build_main_menu()
            )

    # ========== Триал ==========
    @dp.callback_query(F.data == "trial")
    async def cb_trial(call: CallbackQuery):
        ok, msg = vpn_service.activate_trial(
            call.from_user.id,
            call.from_user.username
        )
        if ok:
            link = vpn_service.get_subscription_link(call.from_user.id)
            text = (
                f"✅ {msg}\n\n"
                f"🔗 Ваша ссылка для подключения:\n`{link}`\n\n"
                "📱 Скопируйте ссылку и вставьте в приложение VPN-клиент."
            )
        else:
            text = f"❌ {msg}"
        await call.message.edit_text(text, reply_markup=build_main_menu(), parse_mode="Markdown")

    # ========== Главное меню ==========
    @dp.callback_query(F.data == "menu")
    async def cb_menu(call: CallbackQuery):
        await call.message.edit_text("Главное меню:", reply_markup=build_main_menu())

    # ========== Мой аккаунт ==========
    @dp.callback_query(F.data == "account")
    async def cb_account(call: CallbackQuery):
        user = db.get_user(db_path, call.from_user.id)
        if not user:
            await call.answer("Аккаунт не найден")
            return

        status = "✅ Активна" if user["is_active"] else "❌ Неактивна"
        end = user.get("subscription_end", "—")
        if end and end != "—":
            try:
                end = datetime.fromisoformat(end).strftime("%d.%m.%Y %H:%M")
            except ValueError:
                pass

        text = (
            f"🧾 <b>Ваш аккаунт</b>\n\n"
            f"Статус подписки: {status}\n"
            f"Действует до: {end}\n"
            f"Устройств: {user['device_limit']}\n"
            f"Триал использован: {'Да' if user['is_trial_used'] else 'Нет'}"
        )
        builder = InlineKeyboardBuilder()
        builder.button(text="◀️ Назад", callback_data="menu")
        await call.message.edit_text(text, parse_mode="HTML", reply_markup=builder.as_markup())

    # ========== Купить подписку ==========
    @dp.callback_query(F.data == "buy")
    async def cb_buy(call: CallbackQuery):
        await call.message.edit_text(
            "💳 <b>Выберите тариф</b>\n\nВсе тарифы с безлимитным трафиком:",
            parse_mode="HTML",
            reply_markup=build_tariffs_menu()
        )

    # ========== Инвойс для тарифа ==========
    @dp.callback_query(F.data.startswith("buy_") & ~F.data.startswith("buy_device"))
    async def cb_buy_tariff(call: CallbackQuery, bot: Bot):
        tariff_key = call.data.replace("buy_", "")
        tariff = TARIFFS.get(tariff_key)
        if not tariff:
            await call.answer("Тариф не найден")
            return

        await bot.send_invoice(
            chat_id=call.from_user.id,
            title=f"VPN — {tariff['name']}",
            description=f"Безлимитный VPN на {tariff['name']}",
            payload=f"tariff:{tariff_key}",
            currency="XTR",  # Telegram Stars
            prices=[LabeledPrice(label=tariff["name"], amount=tariff["stars"])],
        )
        await call.answer()

    # ========== Инвойс для устройства ==========
    @dp.callback_query(F.data == "buy_device")
    async def cb_buy_device(call: CallbackQuery, bot: Bot):
        user = db.get_user(db_path, call.from_user.id)
        if not user or not user.get("remnawave_id"):
            await call.answer("Сначала активируйте VPN-аккаунт")
            return

        await bot.send_invoice(
            chat_id=call.from_user.id,
            title="Дополнительное устройство",
            description=f"Увеличить лимит устройств с {user['device_limit']} до {user['device_limit'] + 1}",
            payload="device:extra",
            currency="XTR",
            prices=[LabeledPrice(label="Доп. устройство", amount=EXTRA_DEVICE_STARS)],
        )
        await call.answer()

    # ========== Pre-checkout (обязательно!) ==========
    @dp.pre_checkout_query()
    async def pre_checkout(query: PreCheckoutQuery):
        await query.answer(ok=True)

    # ========== Успешная оплата ==========
    @dp.message(F.successful_payment)
    async def payment_success(message: Message):
        payment = message.successful_payment
        payload = payment.invoice_payload
        telegram_id = message.from_user.id
        amount = payment.total_amount
        charge_id = payment.telegram_payment_charge_id

        user = db.get_user(db_path, telegram_id)
        if not user:
            user = vpn_service.get_or_create_user(telegram_id, message.from_user.username)

        # Сохраняем платёж
        payment_id = db.create_payment(db_path, user["id"], amount, payload)
        db.confirm_payment(db_path, payment_id, charge_id)

        if payload.startswith("tariff:"):
            tariff_key = payload.split(":")[1]
            ok, msg = vpn_service.activate_subscription(
                telegram_id, tariff_key, message.from_user.username
            )
            if ok:
                link = vpn_service.get_subscription_link(telegram_id)
                await message.answer(
                    f"✅ Оплата прошла успешно!\n\n{msg}\n\n"
                    f"🔗 Ваша ссылка VPN:\n`{link}`",
                    parse_mode="Markdown",
                    reply_markup=build_main_menu()
                )
            else:
                await message.answer(f"⚠️ Оплата получена, но ошибка активации: {msg}")

        elif payload == "device:extra":
            ok, msg = vpn_service.add_device(telegram_id)
            await message.answer(
                f"✅ {'Готово! ' + msg if ok else 'Ошибка: ' + msg}",
                reply_markup=build_main_menu()
            )

    # ========== Мой VPN ==========
    @dp.callback_query(F.data == "myvpn")
    async def cb_myvpn(call: CallbackQuery):
        user = db.get_user(db_path, call.from_user.id)
        if not user or not user.get("remnawave_id"):
            await call.message.edit_text(
                "❌ У вас ещё нет VPN аккаунта.\n"
                "Активируйте триал или купите подписку.",
                reply_markup=build_main_menu()
            )
            return

        builder = InlineKeyboardBuilder()
        builder.button(text="🔗 Получить конфиг", callback_data="get_config")
        builder.button(text="◀️ Назад", callback_data="menu")
        builder.adjust(1)
        await call.message.edit_text(
            "📡 <b>Мой VPN</b>\n\nНажмите кнопку для получения конфига:",
            parse_mode="HTML",
            reply_markup=builder.as_markup()
        )

    @dp.callback_query(F.data == "get_config")
    async def cb_get_config(call: CallbackQuery):
        link = vpn_service.get_subscription_link(call.from_user.id)
        if not link:
            await call.answer("Не удалось получить ссылку", show_alert=True)
            return

        text = (
            f"🔗 <b>Ваша ссылка VPN-подписки:</b>\n\n"
            f"<code>{link}</code>\n\n"
            f"📱 <b>Инструкция:</b>\n"
            f"1. Скопируйте ссылку выше\n"
            f"2. Откройте приложение (Happ, Streisand, V2RayNG и т.д.)\n"
            f"3. Добавьте подписку по ссылке\n"
            f"4. Подключитесь к любому серверу\n\n"
            f"❓ Вопросы? Напишите в поддержку."
        )
        builder = InlineKeyboardBuilder()
        builder.button(text="◀️ Назад", callback_data="myvpn")
        await call.message.edit_text(text, parse_mode="HTML", reply_markup=builder.as_markup())

    # ========== О сервисе ==========
    @dp.callback_query(F.data == "about")
    async def cb_about(call: CallbackQuery):
        text = (
            "ℹ️ <b>О сервисе</b>\n\n"
            "🛡 Быстрый и надёжный VPN\n"
            "🌍 Серверы по всему миру\n"
            "⚡️ Протоколы: VLESS, VMess\n"
            "📱 Работает на iOS, Android, Windows, macOS\n\n"
            "💬 Поддержка: @support"
        )
        builder = InlineKeyboardBuilder()
        builder.button(text="◀️ Назад", callback_data="menu")
        await call.message.edit_text(text, parse_mode="HTML", reply_markup=builder.as_markup())

    # Добавляем диагностическую команду /ping
    add_ping_command(dp, vpn_service)

    return bot, dp


def add_ping_command(dp: Dispatcher, vpn_service: VPNService):
    """Добавить команду /ping для диагностики (только для пользователей)"""
    from aiogram.filters import Command

    @dp.message(Command("ping"))
    async def cmd_ping(message: Message):
        ok = vpn_service.remnawave.ping()
        if ok:
            await message.answer("✅ Remnawave API доступен")
        else:
            await message.answer(
                "❌ Remnawave API недоступен\n"
                "Обратитесь к администратору"
            )
