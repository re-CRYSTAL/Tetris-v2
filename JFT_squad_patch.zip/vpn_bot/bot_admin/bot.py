# bot_admin/bot.py - Административный Telegram бот
import logging
from datetime import datetime, timedelta

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import ADMIN_IDS
from database import db
from services.vpn_service import VPNService

logger = logging.getLogger(__name__)


def is_admin(telegram_id: int) -> bool:
    return telegram_id in ADMIN_IDS


def build_admin_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="👥 Список пользователей", callback_data="admin_users")
    builder.button(text="🔍 Найти пользователя", callback_data="admin_search")
    builder.button(text="🎁 Выдать подписку", callback_data="admin_grant")
    builder.button(text="📢 Рассылка", callback_data="admin_broadcast")
    builder.adjust(2)
    return builder.as_markup()


def setup_admin_bot(token: str, vpn_service: VPNService, db_path: str):
    bot = Bot(token=token)
    dp = Dispatcher()

    # Словарь состояний: {admin_tg_id: "state_name"}
    # Для хранения целевого ID при выдаче подписки используем отдельный dict
    states: dict = {}
    grant_targets: dict = {}  # {admin_id: target_telegram_id}

    # ========== /start ==========
    @dp.message(CommandStart())
    async def cmd_start(message: Message):
        if not is_admin(message.from_user.id):
            await message.answer("⛔ Нет доступа")
            return
        await message.answer(
            f"👑 Панель администратора\n\n"
            f"Команды:\n"
            f"/user <id или @username> — найти пользователя\n"
            f"/grant <id или @username> <дни> — выдать подписку\n",
            reply_markup=build_admin_menu()
        )

    # ========== /user <id или @username> ==========
    @dp.message(F.text.startswith("/user"))
    async def cmd_user(message: Message):
        if not is_admin(message.from_user.id):
            return
        parts = message.text.strip().split()
        if len(parts) < 2:
            await message.answer("Использование: /user <telegram_id или @username>")
            return
        await _find_and_show_user(message, parts[1], bot, vpn_service, db_path)

    # ========== /grant <id или @username> <дни> ==========
    @dp.message(F.text.startswith("/grant"))
    async def cmd_grant(message: Message):
        if not is_admin(message.from_user.id):
            return
        parts = message.text.strip().split()
        if len(parts) < 3:
            await message.answer("Использование: /grant <telegram_id или @username> <дни>")
            return

        target_query = parts[1]
        try:
            days = int(parts[2])
        except ValueError:
            await message.answer("❌ Дни должны быть числом")
            return

        target_id = await _resolve_user_id(target_query, db_path, message)
        if not target_id:
            return

        ok, msg = vpn_service.grant_subscription(target_id, days, message.from_user.id)
        await message.answer(msg if ok else f"❌ {msg}")

    # ========== Список пользователей ==========
    @dp.callback_query(F.data == "admin_users")
    async def cb_users(call: CallbackQuery):
        if not is_admin(call.from_user.id):
            return

        users = db.get_all_users(db_path)
        if not users:
            await call.message.edit_text("Нет пользователей", reply_markup=build_admin_menu())
            return

        lines = []
        for u in users[:15]:
            status = "✅" if u["is_active"] else "❌"
            end = _fmt_date(u.get("subscription_end"))
            name = f"@{u['username']}" if u.get("username") else f"id:{u['telegram_id']}"
            lines.append(f"{status} {name} | до {end}")

        text = f"👥 <b>Пользователи</b> (всего: {len(users)})\n\n" + "\n".join(lines)
        if len(users) > 15:
            text += f"\n\n...и ещё {len(users) - 15}"
        text += f"\n\n💡 /user &lt;id&gt; — посмотреть детали\n💡 /grant &lt;id&gt; &lt;дни&gt; — выдать подписку"

        builder = InlineKeyboardBuilder()
        builder.button(text="◀️ Назад", callback_data="admin_menu")
        await call.message.edit_text(text, parse_mode="HTML", reply_markup=builder.as_markup())

    # ========== Найти пользователя ==========
    @dp.callback_query(F.data == "admin_search")
    async def cb_search(call: CallbackQuery):
        if not is_admin(call.from_user.id):
            return
        states[call.from_user.id] = "waiting_search"
        builder = InlineKeyboardBuilder()
        builder.button(text="◀️ Отмена", callback_data="admin_menu")
        await call.message.edit_text(
            "🔍 Введите <b>Telegram ID</b> или <b>@username</b> пользователя:",
            parse_mode="HTML",
            reply_markup=builder.as_markup()
        )

    # ========== Выдать подписку (через меню) ==========
    @dp.callback_query(F.data == "admin_grant")
    async def cb_grant_start(call: CallbackQuery):
        if not is_admin(call.from_user.id):
            return
        states[call.from_user.id] = "grant_step1_user"
        builder = InlineKeyboardBuilder()
        builder.button(text="◀️ Отмена", callback_data="admin_menu")
        await call.message.edit_text(
            "🎁 <b>Выдать подписку</b>\n\n"
            "Шаг 1/2: Введите <b>Telegram ID</b> или <b>@username</b> получателя:",
            parse_mode="HTML",
            reply_markup=builder.as_markup()
        )

    # ========== Обработка текстовых сообщений ==========
    @dp.message(F.text)
    async def handle_text(message: Message):
        uid = message.from_user.id
        if not is_admin(uid):
            return

        state = states.get(uid)
        text = message.text.strip()

        # -- Поиск пользователя --
        if state == "waiting_search":
            states.pop(uid, None)
            await _find_and_show_user(message, text, bot, vpn_service, db_path)

        # -- Выдача подписки шаг 1: получить кому --
        elif state == "grant_step1_user":
            target_id = await _resolve_user_id(text, db_path, message)
            if not target_id:
                states.pop(uid, None)
                return
            grant_targets[uid] = target_id
            states[uid] = "grant_step2_days"
            builder = InlineKeyboardBuilder()
            for d in [7, 14, 30, 90]:
                builder.button(text=f"{d} дней", callback_data=f"grant_days:{d}")
            builder.button(text="◀️ Отмена", callback_data="admin_menu")
            builder.adjust(2)
            await message.answer(
                f"Шаг 2/2: Выберите срок или введите число дней для пользователя <code>{target_id}</code>:",
                parse_mode="HTML",
                reply_markup=builder.as_markup()
            )

        # -- Выдача подписки шаг 2: ввод дней вручную --
        elif state == "grant_step2_days":
            try:
                days = int(text)
                assert 1 <= days <= 3650
            except (ValueError, AssertionError):
                await message.answer("❌ Введите число дней от 1 до 3650")
                return
            states.pop(uid, None)
            target_id = grant_targets.pop(uid, None)
            if not target_id:
                await message.answer("❌ Ошибка: потерян получатель")
                return
            ok, msg = vpn_service.grant_subscription(target_id, days, uid)
            await message.answer(msg if ok else f"❌ {msg}", reply_markup=build_admin_menu())

        # -- Рассылка --
        elif state == "waiting_broadcast":
            states.pop(uid, None)
            users = db.get_all_users(db_path)
            sent, failed = 0, 0
            for u in users:
                try:
                    await bot.send_message(u["telegram_id"], text)
                    sent += 1
                except Exception:
                    failed += 1
            await message.answer(
                f"✅ Рассылка завершена\nОтправлено: {sent} | Ошибок: {failed}",
                reply_markup=build_admin_menu()
            )

        # -- Продление (ввод дней) --
        elif state and state.startswith("extend:"):
            target_id = int(state.split(":")[1])
            states.pop(uid, None)
            try:
                days = int(text)
                assert 1 <= days <= 3650
            except (ValueError, AssertionError):
                await message.answer("❌ Введите число дней от 1 до 3650")
                return

            ok, msg = vpn_service.grant_subscription(target_id, days, uid)
            await message.answer(msg if ok else f"❌ {msg}", reply_markup=build_admin_menu())

    # ========== Быстрые кнопки выбора дней при выдаче ==========
    @dp.callback_query(F.data.startswith("grant_days:"))
    async def cb_grant_days(call: CallbackQuery):
        if not is_admin(call.from_user.id):
            return
        uid = call.from_user.id
        days = int(call.data.split(":")[1])
        states.pop(uid, None)
        target_id = grant_targets.pop(uid, None)
        if not target_id:
            await call.answer("Ошибка: потерян получатель", show_alert=True)
            return
        ok, msg = vpn_service.grant_subscription(target_id, days, uid)
        await call.message.edit_text(msg if ok else f"❌ {msg}", reply_markup=build_admin_menu())

    # ========== Карточка пользователя ==========
    @dp.callback_query(F.data.startswith("admin_enable:"))
    async def cb_enable(call: CallbackQuery):
        if not is_admin(call.from_user.id):
            return
        target_id = int(call.data.split(":")[1])
        user = db.get_user(db_path, target_id)
        if user and user.get("remnawave_id"):
            vpn_service.remnawave.enable_user(user["remnawave_id"])
        db.update_user(db_path, target_id, is_active=1)
        await call.answer("✅ Активирован")
        await _show_user_card_by_id(call.message, target_id, db_path, vpn_service, states)

    @dp.callback_query(F.data.startswith("admin_disable:"))
    async def cb_disable(call: CallbackQuery):
        if not is_admin(call.from_user.id):
            return
        target_id = int(call.data.split(":")[1])
        user = db.get_user(db_path, target_id)
        if user and user.get("remnawave_id"):
            vpn_service.remnawave.disable_user(user["remnawave_id"])
        db.update_user(db_path, target_id, is_active=0)
        await call.answer("🔴 Деактивирован")
        await _show_user_card_by_id(call.message, target_id, db_path, vpn_service, states)

    @dp.callback_query(F.data.startswith("admin_extend:"))
    async def cb_extend(call: CallbackQuery):
        if not is_admin(call.from_user.id):
            return
        target_id = int(call.data.split(":")[1])
        states[call.from_user.id] = f"extend:{target_id}"
        builder = InlineKeyboardBuilder()
        for d in [7, 14, 30, 90]:
            builder.button(text=f"{d} дней", callback_data=f"extend_quick:{target_id}:{d}")
        builder.button(text="◀️ Отмена", callback_data="admin_menu")
        builder.adjust(2)
        await call.message.edit_text(
            f"📅 Продление для <code>{target_id}</code>\nВыберите или введите дни:",
            parse_mode="HTML",
            reply_markup=builder.as_markup()
        )

    @dp.callback_query(F.data.startswith("extend_quick:"))
    async def cb_extend_quick(call: CallbackQuery):
        if not is_admin(call.from_user.id):
            return
        _, target_id_str, days_str = call.data.split(":")
        target_id, days = int(target_id_str), int(days_str)
        states.pop(call.from_user.id, None)
        ok, msg = vpn_service.grant_subscription(target_id, days, call.from_user.id)
        await call.message.edit_text(msg if ok else f"❌ {msg}", reply_markup=build_admin_menu())

    # ========== Рассылка ==========
    @dp.callback_query(F.data == "admin_broadcast")
    async def cb_broadcast(call: CallbackQuery):
        if not is_admin(call.from_user.id):
            return
        states[call.from_user.id] = "waiting_broadcast"
        builder = InlineKeyboardBuilder()
        builder.button(text="◀️ Отмена", callback_data="admin_menu")
        await call.message.edit_text(
            "📢 Введите текст рассылки (HTML разрешён):",
            reply_markup=builder.as_markup()
        )

    # ========== Назад в меню ==========
    @dp.callback_query(F.data == "admin_menu")
    async def cb_admin_menu(call: CallbackQuery):
        states.pop(call.from_user.id, None)
        grant_targets.pop(call.from_user.id, None)
        await call.message.edit_text("👑 Панель администратора", reply_markup=build_admin_menu())




    # ========== /squads — показать все squads с UUID ==========
    @dp.message(F.text == "/squads")
    async def cmd_squads(message: Message):
        if not is_admin(message.from_user.id):
            return
        squads = vpn_service.remnawave.get_all_squads()
        if not squads:
            await message.answer(
                "❌ Не удалось получить список Squads\n"
                "Проверьте соединение с Remnawave"
            )
            return
        lines = ["📋 <b>Internal Squads</b>\n"]
        for s in squads:
            name = s.get("name", "—")
            uuid = s.get("uuid", "—")
            lines.append(f"<b>{name}</b>\n<code>{uuid}</code>\n")
        lines.append(
            "💡 Скопируйте нужный UUID и добавьте в .env:\n"
            "<code>REMNAWAVE_SQUAD_UUID=вставьте-uuid-сюда</code>"
        )
        await message.answer("\n".join(lines), parse_mode="HTML")

    # ========== /debug — диагностика Remnawave ==========
    @dp.message(F.text == "/debug")
    async def cmd_debug(message: Message):
        if not is_admin(message.from_user.id):
            return

        import httpx
        base_url = vpn_service.remnawave.base_url
        token = vpn_service.remnawave.token
        headers = vpn_service.remnawave.headers

        lines = [f"🔧 <b>Диагностика Remnawave</b>\n"]
        lines.append(f"URL: <code>{base_url}</code>")
        lines.append(f"Токен: <code>...{token[-8:] if len(token) > 8 else token}</code>\n")

        # Тест 1: ping
        await message.answer("⏳ Проверяю соединение...", parse_mode="HTML")

        # Тест подключения с разными конфигурациями
        tests = [
            ("С proxy-заголовками (стандарт)", headers),
            ("Без proxy-заголовков", {k: v for k, v in headers.items()
                                       if k not in ("X-Forwarded-Proto", "X-Forwarded-For")}),
        ]

        for test_name, test_headers in tests:
            try:
                with httpx.Client(timeout=5, headers=test_headers) as client:
                    r = client.get(f"{base_url}/api/keygen/get-pub-key")
                    lines.append(f"✅ {test_name}: HTTP {r.status_code}")
            except httpx.ConnectError as e:
                lines.append(f"❌ {test_name}: ConnectError — {str(e)[:80]}")
            except Exception as e:
                lines.append(f"❌ {test_name}: {type(e).__name__} — {str(e)[:80]}")

        # Тест создания пользователя (dry-run)
        lines.append("\n<b>Тест POST /api/users:</b>")
        try:
            with httpx.Client(timeout=10, headers=headers) as client:
                r = client.post(f"{base_url}/api/users", json={
                    "username": "test_debug_do_not_use",
                    "trafficLimitBytes": 0,
                    "trafficLimitStrategy": "NO_RESET",
                    "expireAt": "2025-01-01T00:00:00.000Z",
                    "telegramId": "0",
                    "description": "debug test",
                    "activeUserInbounds": [],
                })
                lines.append(f"Статус: HTTP {r.status_code}")
                lines.append(f"Ответ: <code>{r.text[:300]}</code>")
        except Exception as e:
            lines.append(f"Ошибка: {type(e).__name__}: {str(e)[:150]}")

        await message.answer("\n".join(lines), parse_mode="HTML")

    return bot, dp


# ==================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ====================

def _fmt_date(iso_str: str | None) -> str:
    """Форматировать ISO дату для отображения"""
    if not iso_str:
        return "—"
    try:
        return datetime.fromisoformat(iso_str).strftime("%d.%m.%Y")
    except ValueError:
        return iso_str


async def _resolve_user_id(query: str, db_path: str, message: Message) -> int | None:
    """
    Разрешить запрос (telegram_id или @username) в telegram_id.
    Возвращает int или None, отправляя ошибку в message.
    """
    query = query.lstrip("@").strip()

    # Числовой ID
    if query.isdigit():
        target_id = int(query)
        user = db.get_user(db_path, target_id)
        if not user:
            await message.answer(
                f"❌ Пользователь с ID <code>{target_id}</code> не найден в базе.\n"
                f"Пользователь должен хотя бы раз запустить клиентский бот.",
                parse_mode="HTML"
            )
            return None
        return target_id

    # Username (без @)
    users = db.get_all_users(db_path)
    for u in users:
        if u.get("username") and u["username"].lower() == query.lower():
            return u["telegram_id"]

    await message.answer(
        f"❌ Пользователь @{query} не найден в базе.\n"
        f"Пользователь должен хотя бы раз запустить клиентский бот.",
        parse_mode="HTML"
    )
    return None


async def _find_and_show_user(message: Message, query: str, bot: Bot, vpn_service, db_path: str):
    """Найти пользователя и показать карточку"""
    target_id = await _resolve_user_id(query, db_path, message)
    if not target_id:
        return
    user = db.get_user(db_path, target_id)
    await _show_user_card(message, user, vpn_service)


async def _show_user_card_by_id(message: Message, target_id: int, db_path: str, vpn_service, states: dict):
    user = db.get_user(db_path, target_id)
    if user:
        await _show_user_card(message, user, vpn_service)


async def _show_user_card(message: Message, user: dict, vpn_service):
    """Показать карточку пользователя с кнопками управления"""
    status = "✅ Активен" if user["is_active"] else "❌ Неактивен"
    end = _fmt_date(user.get("subscription_end"))
    trial = "Да" if user["is_trial_used"] else "Нет"
    name = f"@{user['username']}" if user.get("username") else "—"

    text = (
        f"👤 <b>Пользователь</b>\n\n"
        f"Telegram ID: <code>{user['telegram_id']}</code>\n"
        f"Username: {name}\n"
        f"Статус: {status}\n"
        f"Подписка до: {end}\n"
        f"Устройств: {user['device_limit']}\n"
        f"Триал использован: {trial}\n"
        f"Remnawave UUID: <code>{user.get('remnawave_id') or '—'}</code>"
    )

    tid = user["telegram_id"]
    builder = InlineKeyboardBuilder()
    if user["is_active"]:
        builder.button(text="🔴 Деактивировать", callback_data=f"admin_disable:{tid}")
    else:
        builder.button(text="🟢 Активировать", callback_data=f"admin_enable:{tid}")
    builder.button(text="📅 Продлить", callback_data=f"admin_extend:{tid}")
    builder.button(text="◀️ Назад", callback_data="admin_menu")
    builder.adjust(2)

    await message.answer(text, parse_mode="HTML", reply_markup=builder.as_markup())
