# database/db.py - Работа с SQLite базой данных
import sqlite3
import os
from datetime import datetime


def get_connection(db_path: str) -> sqlite3.Connection:
    """Создаём соединение с базой данных"""
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row  # доступ к полям по имени
    return conn


def init_db(db_path: str):
    """Инициализация схемы базы данных"""
    conn = get_connection(db_path)
    cursor = conn.cursor()

    # Таблица пользователей
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER UNIQUE NOT NULL,
            username TEXT,
            remnawave_id TEXT,
            is_trial_used INTEGER DEFAULT 0,
            device_limit INTEGER DEFAULT 1,
            subscription_end TEXT,
            is_active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Таблица платежей
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            telegram_charge_id TEXT,
            amount INTEGER NOT NULL,
            type TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    conn.commit()
    conn.close()


# ==================== USERS ====================

def get_user(db_path: str, telegram_id: int) -> dict | None:
    """Получить пользователя по telegram_id"""
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def create_user(db_path: str, telegram_id: int, username: str = None) -> dict:
    """Создать нового пользователя"""
    conn = get_connection(db_path)
    conn.execute(
        "INSERT OR IGNORE INTO users (telegram_id, username) VALUES (?, ?)",
        (telegram_id, username),
    )
    conn.commit()
    row = conn.execute(
        "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
    ).fetchone()
    conn.close()
    return dict(row)


def update_user(db_path: str, telegram_id: int, **kwargs):
    """Обновить поля пользователя"""
    if not kwargs:
        return
    fields = ", ".join(f"{k} = ?" for k in kwargs)
    values = list(kwargs.values()) + [telegram_id]
    conn = get_connection(db_path)
    conn.execute(
        f"UPDATE users SET {fields} WHERE telegram_id = ?", values
    )
    conn.commit()
    conn.close()


def get_all_users(db_path: str) -> list[dict]:
    """Получить всех пользователей"""
    conn = get_connection(db_path)
    rows = conn.execute("SELECT * FROM users ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_expired_users(db_path: str) -> list[dict]:
    """Получить пользователей с истёкшей подпиской"""
    now = datetime.utcnow().isoformat()
    conn = get_connection(db_path)
    rows = conn.execute(
        "SELECT * FROM users WHERE subscription_end < ? AND is_active = 1 AND subscription_end IS NOT NULL",
        (now,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ==================== PAYMENTS ====================

def create_payment(db_path: str, user_id: int, amount: int, pay_type: str) -> int:
    """Создать запись о платеже"""
    conn = get_connection(db_path)
    cursor = conn.execute(
        "INSERT INTO payments (user_id, amount, type) VALUES (?, ?, ?)",
        (user_id, amount, pay_type),
    )
    payment_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return payment_id


def confirm_payment(db_path: str, payment_id: int, charge_id: str):
    """Подтвердить платёж"""
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE payments SET status = 'completed', telegram_charge_id = ? WHERE id = ?",
        (charge_id, payment_id),
    )
    conn.commit()
    conn.close()
