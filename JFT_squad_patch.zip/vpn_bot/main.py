# main.py - Точка входа, запуск обоих ботов
import asyncio
import logging
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from config import (
    CLIENT_BOT_TOKEN, ADMIN_BOT_TOKEN,
    REMNAWAVE_API_URL, REMNAWAVE_API_TOKEN,
    DATABASE_PATH, CHECK_EXPIRED_INTERVAL_MINUTES,
    ADMIN_IDS,
)
from database.db import init_db
from services.remnawave import RemnawaveAPI
from services.vpn_service import VPNService
from bot_client.bot import setup_client_bot
from bot_admin.bot import setup_admin_bot

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
# Детальный лог для Remnawave (помогает отлаживать API)
logging.getLogger("services.remnawave").setLevel(logging.DEBUG)

logger = logging.getLogger(__name__)


async def check_remnawave_on_start(remnawave: RemnawaveAPI, admin_bot):
    """Проверить соединение с Remnawave при старте и уведомить админов"""
    logger.info(f"Проверка соединения с Remnawave: {remnawave.base_url}")
    ok = remnawave.ping()
    if ok:
        logger.info("✅ Remnawave API доступен")
    else:
        msg = (
            f"⚠️ <b>Внимание!</b> Не удалось подключиться к Remnawave.\n\n"
            f"URL: <code>{remnawave.base_url}</code>\n\n"
            f"Проверьте:\n"
            f"1. REMNAWAVE_API_URL в .env (без /api на конце)\n"
            f"2. REMNAWAVE_API_TOKEN — токен из Settings → API Tokens\n"
            f"3. Сетевую доступность панели"
        )
        logger.error("❌ Remnawave API недоступен!")
        for admin_id in ADMIN_IDS:
            try:
                await admin_bot.send_message(admin_id, msg, parse_mode="HTML")
            except Exception:
                pass


async def scheduler(vpn_service: VPNService, interval_minutes: int):
    """Планировщик деактивации истёкших подписок"""
    while True:
        await asyncio.sleep(interval_minutes * 60)
        try:
            logger.info("Проверка истёкших подписок...")
            vpn_service.deactivate_expired()
        except Exception as e:
            logger.error(f"Ошибка планировщика: {e}")


async def main():
    # Инициализация БД
    init_db(DATABASE_PATH)
    logger.info(f"База данных: {DATABASE_PATH}")

    # Инициализация сервисов
    remnawave = RemnawaveAPI(REMNAWAVE_API_URL, REMNAWAVE_API_TOKEN)
    vpn_service = VPNService(DATABASE_PATH, remnawave)

    # Настройка ботов
    client_bot, client_dp = setup_client_bot(CLIENT_BOT_TOKEN, vpn_service, DATABASE_PATH)
    admin_bot, admin_dp = setup_admin_bot(ADMIN_BOT_TOKEN, vpn_service, DATABASE_PATH)

    logger.info("Запуск ботов...")

    # Проверяем Remnawave при старте
    await check_remnawave_on_start(remnawave, admin_bot)

    await asyncio.gather(
        client_dp.start_polling(
            client_bot,
            allowed_updates=["message", "callback_query", "pre_checkout_query"]
        ),
        admin_dp.start_polling(
            admin_bot,
            allowed_updates=["message", "callback_query"]
        ),
        scheduler(vpn_service, CHECK_EXPIRED_INTERVAL_MINUTES),
    )


if __name__ == "__main__":
    asyncio.run(main())
