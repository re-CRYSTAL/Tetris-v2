# config.py - Конфигурация проекта
import os
from dotenv import load_dotenv

load_dotenv()

# Telegram боты
CLIENT_BOT_TOKEN = os.getenv("CLIENT_BOT_TOKEN", "")
ADMIN_BOT_TOKEN = os.getenv("ADMIN_BOT_TOKEN", "")

# ID администраторов (через запятую)
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "123456789").split(",")]

# Remnawave API
REMNAWAVE_API_URL = os.getenv("REMNAWAVE_API_URL", "http://localhost:3000")
REMNAWAVE_API_TOKEN = os.getenv("REMNAWAVE_API_TOKEN", "")

# SQLite
DATABASE_PATH = os.getenv("DATABASE_PATH", "data/vpn_bot.db")

# Триал настройки
TRIAL_DAYS = 3
TRIAL_TRAFFIC_GB_PER_DAY = 5

# Тарифы (цена в Telegram Stars)
TARIFFS = {
    "14d": {
        "name": "14 дней",
        "days": 14,
        "stars": 100,
        "traffic_gb": 0,  # 0 = безлимит
    },
    "30d": {
        "name": "30 дней",
        "days": 30,
        "stars": 180,
        "traffic_gb": 0,
    },
    "90d": {
        "name": "90 дней",
        "days": 90,
        "stars": 450,
        "traffic_gb": 0,
    },
}

# Доп. устройство
EXTRA_DEVICE_STARS = 50  # цена за 1 доп. устройство

# Планировщик: проверка истёкших подписок (минуты)
CHECK_EXPIRED_INTERVAL_MINUTES = 30
