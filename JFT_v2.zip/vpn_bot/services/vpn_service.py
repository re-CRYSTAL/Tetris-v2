# services/vpn_service.py - Бизнес-логика VPN сервиса
import logging
from datetime import datetime, timedelta
from database import db
from services.remnawave import RemnawaveAPI
from config import TRIAL_DAYS, TRIAL_TRAFFIC_GB_PER_DAY, TARIFFS

logger = logging.getLogger(__name__)


class VPNService:
    def __init__(self, db_path: str, remnawave: RemnawaveAPI):
        self.db_path = db_path
        self.remnawave = remnawave

    def get_or_create_user(self, telegram_id: int, username: str = None) -> dict:
        user = db.get_user(self.db_path, telegram_id)
        if not user:
            user = db.create_user(self.db_path, telegram_id, username)
            logger.info(f"Новый пользователь: tg_id={telegram_id}")
        return user

    def activate_trial(self, telegram_id: int, username: str = None) -> tuple[bool, str]:
        """Активировать триал. Возвращает (успех, сообщение)."""
        user = self.get_or_create_user(telegram_id, username)

        if user["is_trial_used"]:
            return False, "Триал уже был использован"

        # Трафик на весь триал
        traffic_bytes = TRIAL_TRAFFIC_GB_PER_DAY * TRIAL_DAYS * 1024 ** 3

        if not user.get("remnawave_id"):
            # Создаём аккаунт в Remnawave
            rw_user = self.remnawave.create_user(
                telegram_id, username or str(telegram_id),
                days=TRIAL_DAYS,
                traffic_bytes=traffic_bytes,
            )
            if not rw_user:
                return False, "Ошибка создания VPN аккаунта. Проверьте подключение к Remnawave."

            remnawave_uuid = rw_user.get("uuid")
            if not remnawave_uuid:
                logger.error(f"Remnawave не вернул uuid. Ответ: {rw_user}")
                return False, "Ошибка: не получен UUID от Remnawave"

            expire_at = (datetime.utcnow() + timedelta(days=TRIAL_DAYS)).isoformat()
            db.update_user(
                self.db_path, telegram_id,
                remnawave_id=remnawave_uuid,
                is_trial_used=1,
                subscription_end=expire_at,
                is_active=1,
            )
        else:
            # Аккаунт уже есть — включаем и обновляем срок
            new_end = datetime.utcnow() + timedelta(days=TRIAL_DAYS)
            self.remnawave.enable_user(user["remnawave_id"])
            self.remnawave.update_expiry(user["remnawave_id"], new_end)
            db.update_user(
                self.db_path, telegram_id,
                is_trial_used=1,
                subscription_end=new_end.isoformat(),
                is_active=1,
            )

        return True, f"Триал активирован на {TRIAL_DAYS} дня!"

    def activate_subscription(
        self, telegram_id: int, tariff_key: str, username: str = None
    ) -> tuple[bool, str]:
        """Активировать платную подписку."""
        tariff = TARIFFS.get(tariff_key)
        if not tariff:
            return False, "Неизвестный тариф"

        user = self.get_or_create_user(telegram_id, username)
        days = tariff["days"]

        if not user.get("remnawave_id"):
            # Первый раз — создаём аккаунт
            rw_user = self.remnawave.create_user(
                telegram_id, username or str(telegram_id),
                days=days, traffic_bytes=0,
            )
            if not rw_user:
                return False, "Ошибка создания VPN аккаунта"

            remnawave_uuid = rw_user.get("uuid")
            if not remnawave_uuid:
                return False, "Ошибка: не получен UUID от Remnawave"

            expire_at = (datetime.utcnow() + timedelta(days=days)).isoformat()
            db.update_user(
                self.db_path, telegram_id,
                remnawave_id=remnawave_uuid,
                subscription_end=expire_at,
                is_active=1,
            )
        else:
            # Продлеваем от текущей даты окончания
            current_end = user.get("subscription_end")
            try:
                base = datetime.fromisoformat(current_end) if current_end else datetime.utcnow()
                if base < datetime.utcnow():
                    base = datetime.utcnow()
            except (ValueError, TypeError):
                base = datetime.utcnow()

            new_end = base + timedelta(days=days)
            self.remnawave.update_expiry(user["remnawave_id"], new_end)
            self.remnawave.enable_user(user["remnawave_id"])

            db.update_user(
                self.db_path, telegram_id,
                subscription_end=new_end.isoformat(),
                is_active=1,
            )

        return True, f"Подписка активирована на {days} дней!"

    def grant_subscription(
        self, target_id: int, days: int, by_admin_id: int
    ) -> tuple[bool, str]:
        """
        Выдать подписку пользователю вручную (из админ-бота).
        target_id — telegram_id получателя.
        """
        user = db.get_user(self.db_path, target_id)
        if not user:
            return False, f"Пользователь {target_id} не найден в базе"

        if not user.get("remnawave_id"):
            # Создаём аккаунт если нет
            rw_user = self.remnawave.create_user(
                target_id, user.get("username") or str(target_id),
                days=days, traffic_bytes=0,
            )
            if not rw_user:
                return False, "Ошибка создания VPN аккаунта в Remnawave"

            remnawave_uuid = rw_user.get("uuid")
            expire_at = (datetime.utcnow() + timedelta(days=days)).isoformat()
            db.update_user(
                self.db_path, target_id,
                remnawave_id=remnawave_uuid,
                subscription_end=expire_at,
                is_active=1,
            )
        else:
            # Продлеваем
            current_end = user.get("subscription_end")
            try:
                base = datetime.fromisoformat(current_end) if current_end else datetime.utcnow()
                if base < datetime.utcnow():
                    base = datetime.utcnow()
            except (ValueError, TypeError):
                base = datetime.utcnow()

            new_end = base + timedelta(days=days)
            self.remnawave.update_expiry(user["remnawave_id"], new_end)
            self.remnawave.enable_user(user["remnawave_id"])

            db.update_user(
                self.db_path, target_id,
                subscription_end=new_end.isoformat(),
                is_active=1,
            )

        logger.info(f"Админ {by_admin_id} выдал подписку {days} дней пользователю {target_id}")
        return True, f"✅ Подписка {days} дней выдана пользователю {target_id}"

    def add_device(self, telegram_id: int) -> tuple[bool, str]:
        """Добавить дополнительное устройство."""
        user = db.get_user(self.db_path, telegram_id)
        if not user or not user.get("remnawave_id"):
            return False, "Аккаунт VPN не найден"

        new_limit = user["device_limit"] + 1
        result = self.remnawave.set_device_limit(user["remnawave_id"], new_limit)
        if result is None:
            return False, "Ошибка обновления лимита устройств"

        db.update_user(self.db_path, telegram_id, device_limit=new_limit)
        return True, f"Лимит устройств увеличен до {new_limit}"

    def get_subscription_link(self, telegram_id: int) -> str | None:
        """Получить ссылку VPN-подписки для пользователя."""
        user = db.get_user(self.db_path, telegram_id)
        if not user or not user.get("remnawave_id"):
            return None
        return self.remnawave.get_subscription_link(user["remnawave_id"])

    def deactivate_expired(self):
        """Деактивировать пользователей с истёкшей подпиской."""
        expired = db.get_expired_users(self.db_path)
        for user in expired:
            if user.get("remnawave_id"):
                self.remnawave.disable_user(user["remnawave_id"])
            db.update_user(self.db_path, user["telegram_id"], is_active=0)
            logger.info(f"Деактивирован: tg_id={user['telegram_id']}")

        if expired:
            logger.info(f"Деактивировано {len(expired)} истёкших аккаунтов")
